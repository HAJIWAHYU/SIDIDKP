<?php if($paginator->hasPages()): ?>
    <nav role="navigation" aria-label="<?php echo e(__('Pagination Navigation')); ?>" class="flex items-center justify-between">
        
        <!-- Mobile Layout -->
        <div class="flex gap-2 items-center justify-between w-full sm:hidden">
            <?php if($paginator->onFirstPage()): ?>
                <span class="inline-flex items-center px-4 py-2 text-xs font-bold text-slate-400 bg-slate-50/50 border border-slate-200 cursor-not-allowed leading-5 rounded-xl">
                    <?php echo __('pagination.previous'); ?>

                </span>
            <?php else: ?>
                <a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" class="inline-flex items-center px-4 py-2 text-xs font-bold text-slate-650 bg-white border border-slate-200 leading-5 rounded-xl hover:bg-slate-50 hover:text-slate-800 active:scale-[0.98] transition-all duration-150">
                    <?php echo __('pagination.previous'); ?>

                </a>
            <?php endif; ?>

            <?php if($paginator->hasMorePages()): ?>
                <a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" class="inline-flex items-center px-4 py-2 text-xs font-bold text-slate-650 bg-white border border-slate-200 leading-5 rounded-xl hover:bg-slate-50 hover:text-slate-800 active:scale-[0.98] transition-all duration-150">
                    <?php echo __('pagination.next'); ?>

                </a>
            <?php else: ?>
                <span class="inline-flex items-center px-4 py-2 text-xs font-bold text-slate-400 bg-slate-50/50 border border-slate-200 cursor-not-allowed leading-5 rounded-xl">
                    <?php echo __('pagination.next'); ?>

                </span>
            <?php endif; ?>
        </div>

        <!-- Desktop Layout -->
        <div class="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
            <div>
                <p class="text-xs text-slate-500 font-medium">
                    <?php echo __('Menampilkan'); ?>

                    <?php if($paginator->firstItem()): ?>
                        <span class="font-bold text-slate-700"><?php echo e($paginator->firstItem()); ?></span>
                        <?php echo __('sampai'); ?>

                        <span class="font-bold text-slate-700"><?php echo e($paginator->lastItem()); ?></span>
                    <?php else: ?>
                        <?php echo e($paginator->count()); ?>

                    <?php endif; ?>
                    <?php echo __('dari'); ?>

                    <span class="font-bold text-slate-700"><?php echo e($paginator->total()); ?></span>
                    <?php echo $label ?? (request()->routeIs('user.*') ? 'user' : (request()->routeIs('bidang.*') ? 'bidang' : 'surat')); ?>

                </p>
            </div>

            <div>
                <span class="inline-flex shadow-sm rounded-xl border border-slate-200/80 bg-white overflow-hidden">

                    
                    <?php if($paginator->onFirstPage()): ?>
                        <span aria-disabled="true" aria-label="<?php echo e(__('pagination.previous')); ?>">
                            <span class="inline-flex items-center px-3 py-2 text-sm font-medium text-slate-300 bg-slate-50/50 cursor-not-allowed leading-5" aria-hidden="true">
                                <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" />
                                </svg>
                            </span>
                        </span>
                    <?php else: ?>
                        <a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" class="inline-flex items-center px-3 py-2 text-sm font-medium text-slate-500 bg-white leading-5 hover:bg-slate-50/80 hover:text-slate-700 transition-all duration-150" aria-label="<?php echo e(__('pagination.previous')); ?>">
                            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" />
                            </svg>
                        </a>
                    <?php endif; ?>

                    
                    <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php if(is_string($element)): ?>
                            <span aria-disabled="true">
                                <span class="inline-flex items-center px-3.5 py-2 -ml-px text-xs font-semibold text-slate-400 bg-slate-50 cursor-default leading-5"><?php echo e($element); ?></span>
                            </span>
                        <?php endif; ?>

                        
                        <?php if(is_array($element)): ?>
                            <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($page == $paginator->currentPage()): ?>
                                    <span aria-current="page">
                                        <span class="inline-flex items-center px-3.5 py-2 -ml-px text-xs font-bold text-white bg-indigo-600 leading-5"><?php echo e($page); ?></span>
                                    </span>
                                <?php else: ?>
                                    <a href="<?php echo e($url); ?>" class="inline-flex items-center px-3.5 py-2 -ml-px text-xs font-semibold text-slate-650 bg-white leading-5 hover:bg-slate-50/85 hover:text-slate-800 transition-all duration-150" aria-label="<?php echo e(__('Go to page :page', ['page' => $page])); ?>">
                                        <?php echo e($page); ?>

                                    </a>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                    <?php if($paginator->hasMorePages()): ?>
                        <a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" class="inline-flex items-center px-3 py-2 -ml-px text-sm font-medium text-slate-500 bg-white leading-5 hover:bg-slate-50/80 hover:text-slate-700 transition-all duration-150" aria-label="<?php echo e(__('pagination.next')); ?>">
                            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" />
                            </svg>
                        </a>
                    <?php else: ?>
                        <span aria-disabled="true" aria-label="<?php echo e(__('pagination.next')); ?>">
                            <span class="inline-flex items-center px-3 py-2 -ml-px text-sm font-medium text-slate-350 bg-slate-50/50 cursor-not-allowed leading-5" aria-hidden="true">
                                <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" />
                                </svg>
                            </span>
                        </span>
                    <?php endif; ?>
                </span>
            </div>
        </div>
    </nav>
<?php endif; ?>
<?php /**PATH C:\Users\HAJIWAHYU\Documents\E-OFFICE\e-office\resources\views/vendor/pagination/tailwind.blade.php ENDPATH**/ ?>