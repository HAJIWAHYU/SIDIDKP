Halo <?php echo e($surat->penerima->name); ?>,

Ada surat atau disposisi baru nih yang masuk ke akun E-Office kamu.

Silakan langsung dicek ya, kamu bisa masuk lewat tautan ini: https://sso.radenfatah.ac.id/login

Terima kasih ya!
<?php /**PATH C:\Users\HAJIWAHYU\Documents\E-OFFICE\e-office\resources\views/emails/surat_notification_plain.blade.php ENDPATH**/ ?>